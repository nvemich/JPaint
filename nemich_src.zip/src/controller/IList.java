package controller;

public interface IList {
    IList getList();
}
