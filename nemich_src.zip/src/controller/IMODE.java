package controller;

public interface IMODE {
    public void run();
}
