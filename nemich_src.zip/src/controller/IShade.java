package controller;

public interface IShade {
    public void drawShape();
}
