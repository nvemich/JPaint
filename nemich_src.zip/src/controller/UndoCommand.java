package controller;

import java.io.IOException;

public class UndoCommand implements ICommand{
    @Override
    public void run() {
        CommandHistory.undo();
    }


}
