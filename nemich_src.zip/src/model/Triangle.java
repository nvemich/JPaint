package model;

import model.interfaces.IShape;

public class Triangle  {
    public Triangle(){

    }


}
