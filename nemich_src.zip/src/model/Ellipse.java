package model;

import model.interfaces.IShape;

public class Ellipse {
    public Ellipse(){

    }
}
