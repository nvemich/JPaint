package view.gui;

import view.interfaces.IPaintCanvas;

import javax.swing.JComponent;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class PaintCanvas extends JComponent implements IPaintCanvas {

    public PaintCanvas(){
        mouseHandler mouse = new mouseHandler();
        addMouseListener(mouse);


    }
    public Graphics2D getGraphics2D() {
        return (Graphics2D)getGraphics();
    }

    public void DrawShape(int start_x, int start_y, int end_x, int end_y){
        Graphics2D graphics = getGraphics2D();
        int width, height;

        height = end_y - start_y;
        width = end_x - start_x;

        graphics.drawRect(start_x, start_y, width, height);
    }

    //mouse handler to handle all my mouse events, like press and release
    class mouseHandler extends MouseAdapter {

        int start_x , start_y, end_x, end_y ;

        @Override
        public void mousePressed(MouseEvent e) {
            this.start_x = e.getX();
            this.start_y = e.getY();
            System.out.println(start_x+","+start_y);
        }

        @Override
        public void mouseReleased(MouseEvent e) {
            this.end_x = e.getX();
            this.end_y = e.getY();
            System.out.println(end_x+","+end_y);

            DrawShape(start_x, start_y, end_x, end_y);
        }
    }


}
